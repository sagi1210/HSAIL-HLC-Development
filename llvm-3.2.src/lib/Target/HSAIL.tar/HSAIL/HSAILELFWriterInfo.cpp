//===-- HSAILELFWriterInfo.cpp - ELF Writer Info for HSAIL ----------------===//
//
// This file is to be deleted.
